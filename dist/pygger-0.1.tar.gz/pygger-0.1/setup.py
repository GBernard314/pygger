from setuptools import setup
setup(name='pygger',
version='0.1',
description='Swagger doc generator for python code',
url='#',
author='GBernard314',
author_email='guillaume.bernard31415@gmail.com',
license='MIT',
packages=['pygger'],
zip_safe=False)